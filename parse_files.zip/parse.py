import json
from bs4 import BeautifulSoup

with open('listing.html', 'r', encoding='utf-8') as f:
    html_content = f.read()

soup = BeautifulSoup(html_content, 'lxml')

reviews = []

review_elements = soup.select('li.y-css-1sqelp2') 

if not review_elements:
    print("No reviews found.")
else:
    for review in review_elements:
        reviewer_name_element = review.select_one('a.y-css-1x1e1r2')
        star_rating_element = review.select_one('div[aria-label*="star rating"]')
        review_date_element = review.select_one('span.y-css-1vi7y4e')
        text_element = review.select_one('span.raw__09f24__T4Ezm')
        number_of_reviews_element = review.select_one('span.y-css-1ob74fm')
        location_element = review.select_one('span.y-css-1541nhh')


        reviewer_name = reviewer_name_element.get_text(strip=True) if reviewer_name_element else "Name not found"
        star_rating = star_rating_element['aria-label'] if star_rating_element and star_rating_element.has_attr('aria-label') else "Star rating not found"
        review_date = review_date_element.get_text(strip=True) if review_date_element else "Date not found"
        review_text = text_element.get_text(strip=True, separator=' ') if text_element else "Review text not found"
        number_of_reviews = number_of_reviews_element.get_text(strip=True) if number_of_reviews_element else "Number of reviews not found"
        location = location_element.get_text(strip=True) if location_element else "Location not found"

        review_data = {
            "reviewer_name": reviewer_name,
            "star_rating": star_rating,
            "review_date": review_date,
            "review_text": review_text,
            "number_of_reviews": number_of_reviews,
            "location": location
        }
        reviews.append(review_data)

    with open('parsed.json', 'w', encoding='utf-8') as f:
        json.dump(reviews, f, ensure_ascii=False, indent=4)