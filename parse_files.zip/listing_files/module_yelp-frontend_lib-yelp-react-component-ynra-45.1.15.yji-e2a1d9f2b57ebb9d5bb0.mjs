(globalThis.__LOADABLE_LOADED_CHUNKS__=globalThis.__LOADABLE_LOADED_CHUNKS__||[]).push([[56019],{343593:(e,s,i)=>{i.d(s,{A:()=>q,v:()=>T});var n=i(577984),o=(i(351649),i(204106)),r=i(625973),t=i(404821),a=i(553811),l=i(499889),d=i(243553),u=i(498489),g=i(406625),c=i(577723),p=i(703371),h=i.n(p),m=i(934728),b=i(65854),f=i(310521),k=i(632454),v=i(534335),A=i(905972),x=i(918670),w=i(217341),y=i(333223),Y=i(636009),C=i(971523),_=i(340778),E=i(18036),U=i(96550),R=i(114473);const B=n.J1`
    fragment YnraCardFields on ReviewSuggestion {
        suggestedBusiness {
            encid
            name
            alias
            reviewCount
            primaryPhoto {
                encid
                photoUrl {
                    url(size: SQUARE_LARGE)
                }
            }
            reviewDraftForLoggedInUser {
                encid
                rating
            }
            categoryGroups {
                isPLAH
            }
        }
        uuid
        displayedMessages {
            htmlMessage
            icon {
                url
            }
        }
        businessPhotos {
            encid
            photoUrl {
                url(size: SQUARE_90)
            }
        }
    }
`,D=n.J1`
    fragment YnraCardRootFields on Query {
        csrfTokenBlockSuggestion: csrfToken(scope: "/block_review_suggestion")
        csrfTokenImpressions: csrfToken(scope: "/review_suggestions/suggestion_impression/1.0.0")
    }
`,T=(e,s)=>{const{suggestedBusiness:i,uuid:n,displayedMessages:o,businessPhotos:r}=e;h()(i&&n,"Fields should be defined for YNRA suggestion");const{encid:t,name:a,alias:l,reviewCount:d,primaryPhoto:u,reviewDraftForLoggedInUser:g,categoryGroups:c}=i;h()(c,"Business should have defined categoryGroups"),h()(null!==d,"Business should have a defined review count");const{isPLAH:p}=c,m=(r??[]).map(e=>e?.photoUrl?.url).filter(Boolean),{csrfTokenBlockSuggestion:b,csrfTokenImpressions:k}=s;return h()(b&&k,"Csrf tokens should be defined for YNRA"),{businessEncid:t,businessName:a,businessAlias:l,reviewCount:d,initialRating:g?g.rating:null,photoUrl:u?.photoUrl?.url??void 0,uuid:n,displayedMessages:o.map(e=>{let{htmlMessage:s,icon:i}=e;return{htmlMessage:s,iconUrl:i?.url??null}}),userUploadedPhotosUrls:m,showQuestionEntrypoint:Boolean(p)&&!(0,f.qb)(t),blockSuggestionCsrfToken:b,impressionCsrfToken:k}};var S={name:"xdvdnl",styles:"margin-top:auto"},L={name:"8k3ukw",styles:"min-width:0;flex:1;display:flex;flex-direction:column;justify-content:flex-start"},M={name:"nl1qpq",styles:"height:60px;width:60px"},N={name:"1bjrbtb",styles:"flex:0 0 auto;vertical-align:middle;width:200px"};const P=e=>{let{businessEncid:s,businessName:i,businessAlias:n,reviewCount:p,initialRating:f,photoUrl:B,uuid:D,displayedMessages:T,reviewOrigin:P,blockSuggestionCsrfToken:q,impressionCsrfToken:K,onDismiss:F,userUploadedPhotosUrls:H=[],showQuestionEntrypoint:O=!1,onReminderClick:Q,hasDarkBackground:z=!1,hostName:G}=e;const I=(0,m.P)({host:G,businessEncid:s,rating:f,uuid:D,reviewOrigin:P}),j=(0,c.py)(),J=(0,t.Ay)({clickCallback:(e,s)=>{(0,t.PJ)(I,s)},shouldHandleEvent:e=>!(e.target instanceof HTMLInputElement||e.target instanceof HTMLAnchorElement||e.target instanceof HTMLSpanElement)}),W=(0,Y.vM)({host:G,uuid:D,impressionCsrfToken:K});let V;return V=f?(0,R.Y)(E.A,{reviewCount:p,initialRating:f,displayedMessages:T,hasDarkBackground:z}):O?(0,R.Y)(b.A,{absoluteWarUrl:I,businessEncid:s,reviewOrigin:P,hasDarkBackground:z,textStyles:(0,y.q)((0,d.gQ)(x.EzU))}):(0,R.Y)(U.A,{absoluteWarUrl:G?I:void 0,businessEncid:s,uuid:D,reviewOrigin:P,reviewCount:p,displayedMessages:T,hasDarkBackground:z}),(0,R.FD)(r.A,{css:[(0,u.css)("display:flex;flex-direction:row;border-radius:",(0,l.YK)(.5),"px;cursor:pointer;height:100%;min-height:200px;background-color:",A.FSq.get({alpha:z?.15:1}),";position:relative;box-sizing:border-box;",""),(0,y.q)((0,u.css)("min-height:initial;padding:",(0,l.YK)(2),"px;","")),"",""],tagRef:W,bordered:!z,borderColor:A.y4G,textAlign:"left","data-testid":"ynra-card",...J,children:[(0,R.Y)(r.A,{css:[N,(0,y.q)(M),"",""],children:(0,R.Y)("img",{src:B||w,alt:(0,g.Ru)("Photo of %{businessName}",{businessName:i}).toString(),css:[(0,u.css)("border-top-left-radius:",(0,l.YK)(.5),"px;border-bottom-left-radius:",(0,l.YK)(.5),"px;object-fit:cover;width:calc(100% + 2px);height:calc(100% + 2px);margin-left:-1px;margin-top:-1px;",""),(0,y.q)((0,u.css)("border-radius:",(0,l.YK)(.5),"px;","")),"",""]})}),(0,R.FD)(r.A,{marginBottom:1,paddingLeft:2,paddingRight:1,css:L,children:[(0,R.Y)(_.A,{businessName:i,businessAlias:n,hasDarkBackground:z}),(0,R.Y)(r.A,{marginBottom:Q?2:0,children:V}),!Q&&H&&H.length>0&&(0,R.Y)(k.A,{css:[(0,u.css)("margin-top:",(0,l.YK)(2),"px;",""),(0,y.q)((0,u.css)("margin-top:",(0,l.YK)(1),"px;","")),"",""],children:H.map(e=>(0,R.Y)(v.A,{gutter:1,children:(0,R.Y)("img",{alt:"",width:60,height:60,src:e,css:[(0,u.css)("width:60px;height:60px;border-radius:",(0,l.YK)(.5),"px;margin-right:10px;",""),"",""]})},e))}),Boolean(Q)&&(0,R.Y)(r.A,{css:S,children:(0,R.Y)(a.A,{type:"link",size:"small",onClick:e=>{h()(Q,"This event handler won’t be called unless onReminderClick is supplied"),e.preventDefault(),j.logEvent(["contributions","review_solicitation_reminder","0.1"],{business_id_encid:s}),Q({businessName:i}),F&&F()},children:(0,R.Y)(o.x6,{id:(0,g.Ru)("Remind me to review later",{}).toString(),message:(0,g.Ru)("Remind me to review later",{}).toString()})})})]}),q&&F&&(0,R.Y)(C.A,{businessEncid:s,blockSuggestionCsrfToken:q,onDismiss:F})]})};P.fragments={query:B,root:D};const q=P}}]);
//# sourceMappingURL=https://js-sourcemaps.yelpcorp.com/assets/public/module_yelp-frontend_lib-yelp-react-component-ynra-45.1.15.yji-e2a1d9f2b57ebb9d5bb0.mjs.map