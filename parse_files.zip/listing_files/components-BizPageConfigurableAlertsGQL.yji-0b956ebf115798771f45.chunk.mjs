(globalThis.__LOADABLE_LOADED_CHUNKS__=globalThis.__LOADABLE_LOADED_CHUNKS__||[]).push([[10768],{374613:e=>{e.exports={"blue-regular":"blue-regular__09f24__PEwsO","green-regular":"green-regular__09f24__WqaPb","orange-dark":"orange-dark__09f24__ZoXGh","orange-mid":"orange-mid__09f24__G8ZJM","promo-green":"promo-green__09f24__YdbIq","title-spacing":"title-spacing__09f24__NrxJj"}},838394:(e,i,l)=>{l.r(i),l.d(i,{default:()=>y});var r=l(577984),n=l(359098),t=(l(351649),l(68493)),a=l(382144),o=l(584682),c=l(160590),s=l(188306),g=l(553811),d=l(625973),_=l(841606),b=l(374613),u=l.n(b),p=l(114473);const h=e=>{let{action:i,title:l,alertType:r,description:n,subtitle:t}=e;return(0,p.Y)(p.FK,{children:(0,p.Y)(a.A,{type:r,priority:"high",children:(0,p.FD)(c.A,{grid:!0,layoutStack:"small",verticalAlign:"middle",children:[(0,p.FD)(s.A,{children:[(0,p.Y)(d.A,{display:"inline-block",displaySm:"block",children:(0,p.Y)(_.Text,{bold:!0,className:u()["title-spacing"],inline:!0,size:"large",children:l})}),(0,p.Y)(d.A,{display:"inline-block",displaySm:"block",children:t&&(0,p.Y)(_.Text,{bold:!0,inline:!0,size:"large",color:(0,o.eI)(r),children:t})}),n&&(0,p.Y)(d.A,{marginTop:1,children:(0,p.Y)(_.Text,{children:n})})]}),i&&(0,p.Y)(s.A,{nowrap:!0,children:(0,p.Y)(d.A,{marginLeft:2,marginLeftSm:0,marginTopSm:2,children:(0,p.Y)(g.A,{href:i.actionUrl,tagType:"link",type:"secondary-white",children:i.actionText})})})]})})})},A=e=>{let{bizPageConfigurableAlerts:i}=e;return(0,p.Y)(t.A,{useLegacyMargin:!0,type:"block",children:i.map(e=>(0,p.Y)(h,{...e},e.title))})};var f=l(209522);const m=r.J1`
    query GetBizPageConfigurableAlerts($BizEncId: String) {
        business(encid: $BizEncId) {
            bizPageConfigurableAlerts {
                actionUrl
                actionText
                alertType
                description
                subtitle
                title
            }
        }
    }
`,y=e=>{let{businessId:i}=e;const{loading:l,error:r,data:t}=(0,n.I)(m,{variables:{BizEncId:i}});if(l)return null;if(r)throw r;if(!t.business.bizPageConfigurableAlerts.length)return null;const a=t.business.bizPageConfigurableAlerts.map(e=>({action:e.actionUrl&&e.actionText?{actionText:e.actionText,actionUrl:e.actionUrl}:null,alertType:e.alertType,description:e.description,subtitle:e.subtitle,title:e.title}));return(0,p.Y)(f.A,{children:(0,p.Y)(A,{bizPageConfigurableAlerts:a})})}}}]);
//# sourceMappingURL=https://js-sourcemaps.yelpcorp.com/assets/public/components-BizPageConfigurableAlertsGQL.yji-0b956ebf115798771f45.chunk.mjs.map