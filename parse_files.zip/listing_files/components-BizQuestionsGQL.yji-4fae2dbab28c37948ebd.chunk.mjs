(globalThis.__LOADABLE_LOADED_CHUNKS__=globalThis.__LOADABLE_LOADED_CHUNKS__||[]).push([[69834],{643776:(e,n,s)=>{s.d(n,{b:()=>r});var t=s(983335),i=s(406625);const r=e=>"CUSTOMER_SERVICE"===e?(0,i.Ru)("Business Customer Service"):"EMPLOYEE"===e?(0,i.Ru)("Business Employee"):"MANAGER"===e?(0,i.Ru)("Business Manager"):"OWNER"===e?(0,i.Ru)("Business Owner"):((0,t.XX)(new Error(`Missing display string for consumerFacingRole: ${e}`)),"")},883398:(e,n,s)=>{s.r(n),s.d(n,{default:()=>O});var t=s(577984),i=s(359098),r=s(351649),o=s(563348),l=s.n(o),a=s(378340),u=s(625973),c=s(553811),d=s(406625),m=s(841606),h=s(114473);const A=t.J1`
    fragment BusinessCommunityQuestionCtaFields on BusinessCommunityQuestion {
        encid
        business {
            encid
        }
        loggedInUserPermissions {
            canAnswer
        }
        topAnswer {
            encid
        }
        answers(first: 0) {
            totalCount
        }
    }
`,p=e=>{const{encid:n,business:s,loggedInUserPermissions:t,topAnswer:i,answers:r}=e;return{questionEncid:n,businessEncid:s.encid,currentUserCanAnswer:t?.canAnswer??!0,hasPrimaryAnswer:Boolean(i),totalNumAnswers:r.totalCount}},g=e=>{let{questionEncid:n,businessEncid:s,currentUserCanAnswer:t,hasPrimaryAnswer:i,totalNumAnswers:r}=e;const o=`/questions/${s}/${n}`;return i?(0,h.Y)(u.A,{marginTop:1.5,children:(0,h.Y)(c.A,{tagType:"link",href:o,type:"tertiary",size:"small",text:1===r?(0,d.Ru)("See question details"):(0,d.Jb)("See %{smart_count} more answer","See %{smart_count} more answers",r-1)})}):t?(0,h.FD)(m.Text,{size:"inherit",weight:"semibold",inline:!0,children:[" ",(0,h.Y)(m.Link,{size:"inherit",href:o,role:"link",children:(0,d.Ru)("Answer this question")})]}):(0,h.Y)(u.A,{marginTop:1.5,children:(0,h.Y)(c.A,{tagType:"link",type:"tertiary",size:"small",href:o,children:(0,d.Ru)("See question details")})})};g.fragments={query:A};const b=g;var y=s(905972),w=s(160590),Y=s(188306),f=s(643776),_=s(280472);var T=s(703371),C=s.n(T);const x=t.J1`
    fragment BusinessCommunityAnswerInfoLineFields on BusinessCommunityAnswer {
        encid
        helpfulVoteCount
        createdAt {
            utcDateTime
        }
        author {
            __typename
            ... on BizUser {
                encid
                displayName
                consumerFacingRole
            }
            ... on User {
                encid
                displayName
            }
        }
    }
`,q=e=>{const{helpfulVoteCount:n,createdAt:s,author:t}=e;return C()(t,"BusinessCommunityAnswer.author should be defined"),{authorEncid:t.encid,authorType:t.__typename,authorDisplayName:t.displayName,consumerFacingRole:"BizUser"===t.__typename?t.consumerFacingRole:void 0,helpfulVoteCount:n,createdAt:s.utcDateTime}},E=e=>{let{authorEncid:n,authorType:s,authorDisplayName:t,consumerFacingRole:i,helpfulVoteCount:o,createdAt:l,showUser:a=!0,showUserLink:u=!0}=e;const c=((e,n)=>{const[s,t]=r.default.useState("");return r.default.useEffect(()=>{t((0,_.A)(e,n))},[e,n]),s})(l,_.z.LONG),A=i?(0,f.b)(i):null;let p;return"BizUser"===s?(C()(A,"BizUser should have a role"),p=`${t}, ${A.toString()}`):p=u?(0,h.Y)(m.Link,{href:`/user_details?userid=${n}`,children:t}):t,(0,h.FD)(w.A,{gutter:.5,layoutStack:"small",children:[a&&(0,h.Y)(Y.A,{nowrap:!0,children:(0,h.FD)(m.Text,{inline:!0,color:y._uq,weight:"semibold",children:[p," "]})}),(0,h.FD)(Y.A,{fill:!0,children:[(0,h.Y)(m.Text,{inline:!0,color:y._uq,children:c}),Boolean(o)&&(0,h.FD)(h.FK,{children:[" ",(0,h.Y)(m.Text,{inline:!0,bulletBefore:!0,color:y._uq,children:(0,d.Jb)("%{smart_count} person found this helpful","%{smart_count} people found this helpful",o)})]})]})]})};E.fragments={query:x};const R=E;var v=s(890182),z=s(204106),F=s(68493),k=s(208608);const B=function(e){return(0,h.Y)(k.A,{...e})};var D=s(918670),N=s(209522),L=s(372627);const S={name:"1m6y8ri",styles:"overflow-wrap:break-word!important;whitespace:pre-line"},U=e=>{let{text:n,topAnswerInfoLineProps:s}=e;const[t,i]=(0,r.useState)(!1),o=(0,L.b)(n,250),l=(0,h.FD)(m.Text,{css:S,size:"large",children:[o," ",o!==n&&(0,h.Y)(m.Text,{weight:"semibold",size:"inherit",inline:!0,children:(0,h.Y)(m.Link,{role:"button",handleClick:e=>{e.preventDefault(),i(!0)},size:"inherit",children:(0,d.Ru)("more",{},"Expand truncated text")})})]}),a=(0,h.FD)(m.Text,{css:S,size:"large",children:[n," ",(0,h.Y)(m.Text,{weight:"semibold",size:"inherit",inline:!0,children:(0,h.Y)(m.Link,{role:"button",handleClick:e=>{e.preventDefault(),i(!1)},size:"inherit",children:(0,d.Ru)("less",{},"Collapse truncated text")})})]});return(0,h.FD)(h.FK,{children:[t?a:l,(0,h.Y)(u.A,{marginTop:.5,children:(0,h.Y)(R,{...s,showUserLink:!1})})]})},Q=e=>{let{content:n,totalAnswers:s,questionCtaProps:t,topAnswerText:i,topAnswerInfoLineProps:r}=e,o=null;return r&&i?o=(0,h.Y)(U,{text:i,topAnswerInfoLineProps:r}):s||(o=(0,h.Y)(m.Text,{inline:!0,size:"large",children:(0,h.Y)(z.x6,{id:(0,d.Ru)("No answers yet.",{}).toString(),message:(0,d.Ru)("No answers yet.",{}).toString()})})),(0,h.FD)(h.FK,{children:[(0,h.Y)(u.A,{marginTop:2,marginBottom:2,children:(0,h.FD)(w.A,{gutter:2,verticalAlign:"baseline",children:[(0,h.Y)(Y.A,{children:(0,h.Y)(m.Text,{bold:!0,size:"large",children:(0,d.Ru)("Q:",{},"Biz Q&A - Abbreviation for a question (noun)")})}),(0,h.Y)(Y.A,{fill:!0,children:(0,h.Y)(m.Text,{bold:!0,size:"large",weight:"semibold",children:n})})]})}),(0,h.Y)(u.A,{marginTop:2,marginBottom:2,children:(0,h.FD)(w.A,{gutter:2,verticalAlign:"baseline",children:[(0,h.Y)(Y.A,{children:(0,h.Y)(m.Text,{bold:!0,size:"large",children:(0,d.Ru)("A:",{},"Biz Q&A - Abbreviation for an answer to a question (noun)")})}),(0,h.FD)(Y.A,{fill:!0,children:[o,(0,h.Y)(b,{...t})]})]})})]})};var P=s(829587);const I=r.default.memo(e=>{let{businessName:n,businessEncid:s,questions:t,totalQuestions:i}=e;const r=`/questions/${s}`,o=(l=t.length,i-l>0?(0,d.Jb)("See %{smart_count} question","See all %{smart_count} questions",{smart_count:i}):null);var l;const a=i?(0,h.FD)(h.FK,{children:[t.length?(0,h.Y)(u.A,{children:(0,h.Y)(F.A,{useLegacyMargin:!0,type:"block",spacing:5,children:t.map(e=>(0,h.Y)(Q,{...e},e.content))})}):(0,h.Y)(u.A,{children:(0,h.Y)(u.A,{marginBottom:2,children:(0,h.Y)(m.Text,{size:"large",children:(0,h.Y)(z.x6,{id:(0,d.Ru)("Got a question about <0>%{businessName}</0>? Ask the Yelp community!",{businessName:n}).toString(),message:(0,d.Ru)("Got a question about <0>%{businessName}</0>? Ask the Yelp community!",{businessName:n}).toString(),values:{businessName:n},components:{0:(0,h.Y)(m.Text,{inline:!0,style:D.amR})}})})})}),o&&(0,h.Y)(u.A,{marginTop:4,children:(0,h.Y)(c.A,{tagType:"link",href:r,children:o})})]}):(0,h.Y)(h.FK,{children:(0,h.Y)(u.A,{children:(0,h.Y)(m.Text,{size:"large",children:(0,h.Y)(z.x6,{id:(0,d.Ru)("Yelp users haven’t asked any questions yet about <0>%{businessName}</0>.",{businessName:n}).toString(),message:(0,d.Ru)("Yelp users haven’t asked any questions yet about <0>%{businessName}</0>.",{businessName:n}).toString(),values:{businessName:n},components:{0:(0,h.Y)(m.Text,{inline:!0,style:D.amR})}})})})}),A={linkText:"Ask a question",linkUrl:r,linkIcon:(0,h.Y)(B,{color:"inherit"}),isExternalLink:!1},{level:p,displayLevel:g}=(0,P.Z)("bizQuestions");return(0,h.Y)(N.A,{title:(0,d.Ru)("Ask the Community"),linkProps:A,titleLevel:p,displayTitleLevel:g,children:a})}),$=t.J1`
    ${b.fragments.query}
    ${R.fragments.query}

    query GetBizPageCommunityQuestionsData($businessEncid: String) {
        business(encid: $businessEncid) {
            encid
            name
            isCommunityQuestionsEnabled
            communityQuestions(first: 2) {
                totalCount
                edges {
                    node {
                        ...BusinessCommunityQuestionCtaFields
                        encid
                        text
                        answers(first: 0) {
                            totalCount
                        }
                        topAnswer {
                            ...BusinessCommunityAnswerInfoLineFields
                            encid
                            text
                        }
                    }
                }
            }
        }
    }
`,O=r.default.memo(e=>{let{businessEncid:n,locale:s}=e;const t=(0,a.A)(),{loading:r,error:o,data:u}=(0,i.I)($,{variables:{businessEncid:n}});if(o)throw l()(o);if(r||!u)return(0,h.Y)(v.A,{uniqueKey:"biz-questions-gql-shimmer"});const{business:{name:c,isCommunityQuestionsEnabled:d,communityQuestions:m}}=u;if(!d)return null;const{totalCount:A,edges:g}=m;"en_US"===s&&A>2&&t("yelp.seo_msite.biz_details.show_expanded_questions_and_answers");const b=g.map(e=>{let{node:n}=e;return{content:n.text,totalAnswers:n.answers.totalCount,questionCtaProps:p(n),topAnswerText:n.topAnswer?.text,topAnswerInfoLineProps:n.topAnswer?q(n.topAnswer):void 0}});return(0,h.Y)(I,{businessName:c,businessEncid:n,questions:b,totalQuestions:A})})}}]);
//# sourceMappingURL=https://js-sourcemaps.yelpcorp.com/assets/public/components-BizQuestionsGQL.yji-4fae2dbab28c37948ebd.chunk.mjs.map