(globalThis.__LOADABLE_LOADED_CHUNKS__=globalThis.__LOADABLE_LOADED_CHUNKS__||[]).push([[11286],{805016:(e,i,n)=>{n.r(i),n.d(i,{default:()=>g});var r=n(577984),s=n(359098),o=(n(351649),n(382144)),a=n(204106),d=n(841606),t=n(406625),l=n(703371),c=n.n(l),m=n(114473);const u=r.J1`
    query GetUnconfirmedReviewAlertData($businessEncid: String!) {
        loggedInUser {
            hasUnconfirmedReviewForBusiness(businessEncid: $businessEncid)
            primaryEmail {
                emailAddress
                bounced
                confirmed
            }
        }
    }
`,g=e=>{let{businessEncid:i}=e;const{loading:n,error:r,data:l}=(0,s.I)(u,{variables:{businessEncid:i}});if(n)return null;if(r)throw r;if(!l?.loggedInUser||!l?.loggedInUser?.hasUnconfirmedReviewForBusiness)return null;const g=l?.loggedInUser?.primaryEmail,f="/profile_email_notifications";return c()(g,"Logged in user must have a primary email address."),(0,m.FD)(o.A,{type:"warning",children:[(0,m.FD)(d.Text,{weight:"bold",inline:!0,size:"inherit",children:[(0,t.Ru)("Your review has not been posted yet! To post it you must first confirm your email address.")," "]}),(0,m.Y)(d.Text,{inline:!0,size:"inherit",children:g.bounced?(0,m.Y)(a.x6,{id:(0,t.Ru)("We noticed we can no longer send emails to %{0}. <0>Please confirm or update your email address.</0>",{0:g.emailAddress}).toString(),message:(0,t.Ru)("We noticed we can no longer send emails to %{0}. <0>Please confirm or update your email address.</0>",{0:g.emailAddress}).toString(),values:{0:g.emailAddress},components:{0:(0,m.Y)(d.Link,{size:"inherit",href:f})}}):(0,m.Y)(a.x6,{id:(0,t.Ru)("Check your inbox and spam folders for a confirmation email, or <0>click here to resend.</0>",{}).toString(),message:(0,t.Ru)("Check your inbox and spam folders for a confirmation email, or <0>click here to resend.</0>",{}).toString(),components:{0:(0,m.Y)(d.Link,{size:"inherit",href:f})}})})]})}}}]);
//# sourceMappingURL=https://js-sourcemaps.yelpcorp.com/assets/public/components-UnconfirmedReviewAlert.yji-af12c5ec879814152df7.chunk.mjs.map