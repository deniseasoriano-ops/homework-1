(globalThis.__LOADABLE_LOADED_CHUNKS__=globalThis.__LOADABLE_LOADED_CHUNKS__||[]).push([[69042],{206988:(e,t,r)=>{r.r(t),r.d(t,{GET_MAP_BOX_V2_DATA_QUERY:()=>k,STATIC_MAP_HEIGHT_FULL:()=>O,STATIC_MAP_HEIGHT_REDUCED:()=>M,STATIC_MAP_WIDTH:()=>U,createMapBoxV2PropsFromData:()=>P,default:()=>z,getAddressProps:()=>H,getServiceAreaText:()=>y,getShowDirectionsCta:()=>F,getStaticMapProps:()=>x});var n=r(577984),i=r(359098),a=r(351649),s=r(406625),o=r(563348),c=r.n(o),l=r(573516),d=r(905972),u=r(553811),h=r(160590),S=r(188306),_=r(201173),f=r(625973),g=r(841606),p=r(637236),A=r(566555),m=r(421157),I=r(350863),E=r.n(I),T=r(925555),N=r.n(T),v=r(114473);const B=e=>{let{src:t,srcSet:r,width:n,height:i,altText:o,marker:c}=e;const l=(0,a.useContext)(p.default),d=l.v2_enabled?N():E();let u,h;if(u=o||(0,s.Ru)("Map").toString(),c)if(l.v2_enabled){const{image:e,width:t,height:r,anchorY:n}=(0,A.Jo)(m.vX.BUSINESS,!1);h=(0,v.Y)(f.A,{className:d.marker,style:{width:t,height:r,marginBottom:n/-2},dangerouslySetInnerHTML:{__html:e}})}else h=(0,v.Y)(_.E9,{className:d.marker,src:c.src,srcSet:c.srcSet,width:c.width,height:c.height,style:{marginLeft:c.offsetX,marginBottom:c.offsetY}});return(0,v.FD)(f.A,{overflow:"hidden",className:d.container,style:{width:n,height:i},children:[(0,v.Y)(_.E9,{src:t,srcSet:r,width:n,height:i,alt:u}),h]})},D=B;var b=r(247595),C=r(35772),Y=r(208439),w=r(201221);const L=(0,C.o)(e=>{let{addressLines:t,adSyndicationTrackLead:r,formattedNeighborhoods:n,containerBusiness:i,mapUrl:a}=e;const o=()=>{r(b.V.DIRECTION)};let c;return i&&(c=(0,v.FD)(f.A,{marginBottom:1,children:[(0,v.Y)(g.Text,{color:d.RwV,children:(0,s.Ru)("Located in:")}),(0,v.Y)(g.Text,{size:"large",children:(0,v.Y)(g.Link,{size:"inherit",href:i.url,children:i.displayName})})]})),(0,v.FD)(v.FK,{children:[c,(0,v.Y)(_.pV,{children:t.map((e,r)=>{if(0===r)return a?(0,v.Y)(g.Text,{weight:"semibold",color:d.oQc,children:(0,v.Y)(g.Link,{href:a,role:"link",size:"inherit",handleClick:o,children:(0,v.Y)(w.A,{children:e})},e)},"map"):(0,v.Y)(g.Text,{weight:"bold",size:"large",children:(0,v.Y)(w.A,{children:e})},e);const i=!n&&r===t.length-1;return(0,v.Y)(g.Text,{weight:i?null:"bold",children:(0,v.Y)(w.A,{children:e})},e)})}),n&&(0,v.Y)(v.FK,{children:n&&(0,v.Y)(g.Text,{weight:"semibold",children:n})})]})}),X=a.default.memo(e=>{const t=Boolean(e.addressProps),r=Boolean(e.serviceAreaText),n=()=>{e.adSyndicationTrackLead(b.V.DIRECTION),(0,Y.A)({event:"biz_directions_opened"})};let i,a=!1;return(t||r)&&(a=!0),e.serviceAreaText&&(i=t?(0,v.Y)(f.A,{marginTop:.5,children:(0,v.Y)(g.Text,{color:d.RwV,children:e.serviceAreaText})}):(0,v.Y)(g.Text,{color:d.fLO,size:"large",weight:"bold",children:e.serviceAreaText})),(0,v.FD)(_.i,{style:{width:e.staticMapProps.width},children:[(0,v.Y)(g.Link,{display:"block",role:"link",handleClick:n,href:e.mapsUrl,children:(0,v.Y)(D,{...e.staticMapProps})}),a&&(0,v.Y)(f.A,{marginTop:3,children:(0,v.FD)(h.A,{gutter:1.5,children:[(0,v.FD)(S.A,{fill:!0,children:[t&&(0,v.Y)(L,{...e.addressProps}),i]}),e.showDirectionsCta&&(0,v.Y)(S.A,{nowrap:!0,children:(0,v.Y)(u.A,{size:"standard",tagType:"link",onClick:n,href:e.mapsUrl,type:"secondary",children:(0,s.Ru)("Get directions")})})]})})]})}),R=(0,C.o)(X),U=315,O=180,M=150,k=n.J1`
    query GetMapBoxV2Data(
        $BizEncId: String
        $StaticMapWidth: Int
        $StaticMapHeightFull: Int
        $StaticMapHeightReduced: Int
    ) {
        business(encid: $BizEncId) {
            encid
            name
            alias
            hasStorefrontAddress
            location {
                encid
                address {
                    formatted
                }
                neighborhoods
                accuracy {
                    canShowDirections
                }
            }
            containerBusiness {
                encid
                name
                alias
            }
            staticMapHeightFull: map(width: $StaticMapWidth, height: $StaticMapHeightFull) {
                src
                srcSet
                marker {
                    width
                    height
                    src
                    srcSet
                    offsetX
                    offsetY
                }
            }
            staticMapHeightReduced: map(width: $StaticMapWidth, height: $StaticMapHeightReduced) {
                src
                srcSet
                marker {
                    width
                    height
                    src
                    srcSet
                    offsetX
                    offsetY
                }
            }
            serviceArea(userType: consumer) {
                eligible
                areas
                primaryLocation {
                    formatted
                }
            }
        }
    }
`,x=(e,t,r)=>{const{src:n,srcSet:i,marker:a}=r?e:t;return{src:n,srcSet:i,marker:a,width:U,height:r?M:O}},y=e=>{const{eligible:t,areas:r,primaryLocation:n}=e;let i=null;return t&&n&&n.formatted?i=n.formatted:t&&r&&r.length>0&&(i=r[0]),i?(0,s.Ru)("Serving %{area} Area",{area:i}).toString():null},H=e=>{const{alias:t,location:{address:{formatted:r},neighborhoods:n}}=e,i=e.containerBusiness?{displayName:e.containerBusiness.name,url:`/biz/${e.containerBusiness.alias}`}:null,a=r?r.split("\n"):[],s=Boolean(n)&&n.length>0?n.join(", "):null;return r?{addressLines:a,formattedNeighborhoods:s,containerBusiness:i,mapUrl:`/map/${t}`}:null},F=e=>{const{address:{formatted:t},accuracy:{canShowDirections:r}}=e,n=t?t.split("\n"):null;return r&&Boolean(n)},P=e=>{const t=e.business.hasStorefrontAddress,r=H(e.business),n=y(e.business.serviceArea),i=Boolean(r)&&t||Boolean(n);return{mapsUrl:`/map/${e.business.alias}`,staticMapProps:x(e.business.staticMapHeightReduced,e.business.staticMapHeightFull,i),serviceAreaText:n,addressProps:t?r:null,showDirectionsCta:!!t&&F(e.business.location)}},z=e=>{const{loading:t,error:r,data:n}=(0,i.I)(k,{variables:{BizEncId:e.businessId,StaticMapWidth:U,StaticMapHeightFull:O,StaticMapHeightReduced:M}});if(t)return(0,v.Y)(l.A,{});if(r)throw c()(r);const a=P(n);return(0,v.Y)(R,{...a})}},350863:e=>{e.exports={container:"container__09f24__MKzDI",marker:"marker__09f24__yWP5Q"}},566555:(e,t,r)=>{r.d(t,{$l:()=>f,Hg:()=>A,Jo:()=>h,YI:()=>g,_c:()=>a,lq:()=>u,oN:()=>_});var n=r(262246),i=r(421157);function a(e,t){const r={...t},n={...t.icon};return n.size=[e.width,e.height],n.scaledSize=n.size,n.anchorOffset=[e.anchorX,e.anchorY],r.icon=n,r}function s(e,t){const r={...e};return Object.keys(t).forEach(e=>{r.image=r.image.replace(`{${e}}`,t[e].toString())}),r}function o(e){return e?i.UE:i.FH}function c(e){return s(i.Vg,{color:e?i.f4:i.rj})}function l(e){return s(i.qz,{color:o(e)})}function d(){return s(i.VQ,{starColor:i.UE,color:i.pQ})}function u(e,t){let r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"",n=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"";switch(e){case i.vX.BUSINESS:case i.vX.RAINBOW_BUSINESS:return function(e,t){return s(i.v,{markerText:t,color:o(e),textColor:o(!e)})}(t,r);case i.vX.AD_BUSINESS:case i.vX.RAINBOW_AD_BUSINESS:return function(e,t){const r=t||i.AL,[n,a,o]=e?[i.UE,r,r]:[r,r,i.UE];return s(i.jY,{color:n,starColor:o,strokeColor:a})}(t,n);case i.vX.CURRENT_LOCATION:return function(e){return e?i.XL:i.$W}(t);case i.vX.PRECISE_LOCATION:return c(t);case i.vX.STARRED:return function(e){return s(i.VQ,{starColor:o(!e),color:o(e)})}(t);case i.vX.DIRECTIONS:return c(t);case i.vX.SMALL_BUSINESS:return function(e){return s(i.by,{color:o(e)})}(t);case i.vX.FUZZY_LOCATION:return l(t);case i.vX.HIDDEN_LOCATION:default:return d()}}function h(e,t){let r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"";switch(e){case i.vX.BUSINESS:return function(e,t){return""===t?e?i.GX:i.Ek:s(e?i.Gh:i.a1,{label:t})}(t,r);case i.vX.AD_BUSINESS:return t?i.US:i.iB;case i.vX.CURRENT_LOCATION:return t?i.Yl:i.mv;case i.vX.DIRECTIONS:case i.vX.PRECISE_LOCATION:return t?i.a_:i.aG;case i.vX.STARRED:return t?i.y_:i.sr;case i.vX.SMALL_BUSINESS:return t?i.tQ:i.ZG;case i.vX.FUZZY_LOCATION:return l(t);case i.vX.RAINBOW_BUSINESS:return function(e,t){return""===t?e?i.b1:i.B0:s(e?i.ae:i.CO,{label:t,labelshadow:t})}(t,r);case i.vX.RAINBOW_AD_BUSINESS:return function(e){return e?i.Cx:i.q7}(t);case i.vX.UNINDEXED_BUSINESS:return t?i.GX:i.Ek;case i.vX.HIDDEN_LOCATION:default:return d()}}function S(e,t){return e.toString().split(":").includes(t)}function _(e){return S(e,i.vX.AD_BUSINESS)}function f(e){return Number.isNaN(parseInt(e,10))?_(e)||"demo_ad_business"===e?function(e){return S(e,"below_organic")}(e)?1:i.ux:0:i.ux-parseInt(e,10)}function g(e){return e<-180||e>180?((e+180)%360+360)%360-180:e}let p=null;function A(){return p||(p=new n.A({isSitRepEnabled:!1,enabledSitRepChannels:{[n.A.prototype.ChannelNames.SEARCH_UX]:!0},servletName:"none"},{disableBeacon:!1})),p}},925555:e=>{e.exports={container:"container__09f24__fZQnf",marker:"marker__09f24__PujM4"}}}]);
//# sourceMappingURL=https://js-sourcemaps.yelpcorp.com/assets/public/MapBoxV2GQL.yji-71fca7d4904fd507c990.chunk.mjs.map